module Apifood
  VERSION = "0.1.1"
end
